<?php

$connect = new mysqli("localhost","u320983746_dentalClinic1","[!WQmRJA@4Xt","u320983746_dentalclinic");
header('Access-Control-Allow-Origin: *');


if($connect){

	
}else{
	
	echo "connection failed";
	exit();
}

